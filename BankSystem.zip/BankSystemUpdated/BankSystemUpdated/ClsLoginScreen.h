#pragma once
#include "Global.h"
#include "clsUser.h"
#include "ClsScreen.h"
#include "ClsMainClientScreen.h"
class ClsLoginScreen:protected clsScreen
{
private :
	static bool _Login()
	{
		bool LoginFailed = false;
		string UserName, Password;
		short NumberOfTrial = 2;

		do {
			cout << "Enter User Name : \n";
			cin >> UserName;
			cout << "Enter Password : \n";
			cin >> Password;
			CurrentUser = clsUser::Find(UserName, Password);
			LoginFailed = CurrentUser.IsEmpty();
			if (LoginFailed)
			{
				cout << "\n Invalid User Name , Or Password:\n";
				cout << "You have " << NumberOfTrial-- << " trials to login" << endl;
			}
			if (NumberOfTrial == -1)
			{
				cout << "\nYou have blocked after 3 trials\n";
				return false;
			}
			
		} while (LoginFailed);
		
		CurrentUser.RegisterLogIn();
		clsMainScreen::ShowMainMenue();
		return true;
	}
public:
	static bool showLoginScreen()
	{
		
		system("cls");
		clsScreen::_DrawScreenHeader("\t Login Screen");
		return _Login();
	}
};



