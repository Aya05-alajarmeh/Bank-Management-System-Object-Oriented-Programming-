#include "ClsLoginScreen.h"
#include <iostream>
using namespace std;
int main()
{
    while (true)
        if (!ClsLoginScreen::showLoginScreen())
            break;
    system("pause>0");
    return 0;
}
