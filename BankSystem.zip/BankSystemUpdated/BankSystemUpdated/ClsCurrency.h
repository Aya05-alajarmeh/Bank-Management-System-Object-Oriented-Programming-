#pragma once
#include <iostream>
#include "ClsString.h"
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class ClsCurrency
{
private :
	enum enMode { EmptyMode = 0 , UpdateMode = 1};
	string _Country;
	string _CurrencyName;
	string _CurrencyCode;
	float _Rate;
	enMode _Mode;

	static ClsCurrency _ConvertLineToCurrncyObject(string Line , string Seperator = "#//#")
	{
		vector<string > vDate = clsString::Split(Line,Seperator);

		return ClsCurrency(enMode::UpdateMode, vDate[0], vDate[1], vDate[2], stof(vDate[3]));
	}

	static ClsCurrency _GetEmptyObject()
	{
		return ClsCurrency(enMode::EmptyMode, "", "", "", 0);
	}

	static vector<ClsCurrency> _LoadCurrencyFromFile()
	{
		vector<ClsCurrency> VCurrency;
		fstream MyFile;

		MyFile.open("Currencies.txt", ios::in);

		if (MyFile.is_open())
		{
			string Line;
			while (getline(MyFile, Line))
			{
				ClsCurrency Currency = _ConvertLineToCurrncyObject(Line);

				VCurrency.push_back(Currency);
			}
			MyFile.close();
		}
		return VCurrency;
	}

	static string _ConvertCurrencyObjectToLine(ClsCurrency C,string Seperator ="#//#")
	{
		string DataLine = "" ;
		DataLine += C.Country() + Seperator;
		DataLine += C.CurrencyCode() + Seperator;
		DataLine += C.CurrencyName() + Seperator;
		DataLine += to_string(C.Rate());
		return DataLine;
	}

	static void _SaveCurrencyDateToFile(vector<ClsCurrency> VCurrency)
	{
		fstream MyFile;
		MyFile.open("Currencies.txt", ios::out);
	    if (MyFile.is_open())
		{
			for (ClsCurrency C : VCurrency)
			{
				string DataLine = _ConvertCurrencyObjectToLine(C);
				MyFile << DataLine << endl;
			}
		}
		MyFile.close();
	}

	void _Update()
	{
		vector<ClsCurrency> _vCurrencys;
		_vCurrencys = _LoadCurrencyFromFile();

		for (ClsCurrency C : _vCurrencys)
		{
			if (C.CurrencyCode() == CurrencyCode())
			{
				C = *this;
				break;
			}
		}
		_SaveCurrencyDateToFile(_vCurrencys);
	}

public:

	ClsCurrency(enMode Mode , string Country , string CurrencyCode, string CurrencyName, float Rate){
		_Mode = Mode;
		_CurrencyCode = CurrencyCode;
		_CurrencyName = CurrencyName;
		_Rate = Rate;
		_Country = Country;
	}

	bool IsEmpty()
	{
		return (_Mode == enMode::EmptyMode);
	}

	string Country()
	{
		return _Country;
	}

	string CurrencyName()
	{
		return _CurrencyName;
	}

	string CurrencyCode()
	{
		return _CurrencyCode;
	}

	float Rate()
	{
		return _Rate;
	}

	void UpdateRate(float Rate)
	{
		_Rate = Rate;
		_Update();
	}

	static ClsCurrency FindByCode(string CurrencyCode)
	{
		CurrencyCode = clsString::UpperAllString(CurrencyCode);

		fstream MyFile;
		MyFile.open("Currencies.txt", ios::in);
		
		if (MyFile.is_open())
		{
			string Line; 
			while (getline(MyFile, Line))
			{
				ClsCurrency Currency = _ConvertLineToCurrncyObject(Line);
				if (clsString::UpperAllString(Currency.CurrencyCode()) == CurrencyCode)
				{
					MyFile.close();
					return Currency;
				}
			}
			MyFile.close();
		}
		return _GetEmptyObject();
	}
	
	static ClsCurrency FindByCountry(string CountryName)
	{
		CountryName = clsString::UpperAllString(CountryName);

		fstream MyFile;
		MyFile.open("Currencies.txt", ios::in);

		if (MyFile.is_open())
		{
			string Line;
			while (getline(MyFile, Line))
			{
				ClsCurrency Currency = _ConvertLineToCurrncyObject(Line);
				if (clsString::UpperAllString(Currency.Country())== CountryName)
				{
					MyFile.close();
					return Currency;
				}
			}
			MyFile.close();
		}
		return _GetEmptyObject();
	}

	static bool IsCurrencyExist(string CurrencyCode)
	{
		ClsCurrency C = FindByCode(CurrencyCode);
	
		return (!C.IsEmpty());
	}

	static vector<ClsCurrency> GetCurrenciesList()
	{
		return _LoadCurrencyFromFile();
	}

	static vector <ClsCurrency> GetAllUSDRates()
	{
		return _LoadCurrencyFromFile();
	}

	float ConvertToUSD(float Amount)
	{
		return (float)(Amount / Rate());
	}

	float ConvertToOtherCurrency(float Amount, ClsCurrency Currency2)
	{
		float AmountInUSD = ConvertToUSD(Amount);

		if (Currency2.CurrencyCode() == "USD")
		{
			return AmountInUSD;
		}

		return (float)(AmountInUSD * Currency2.Rate());

	}


};