#pragma once
#include <iostream>
#include <iostream>
#include <string>
#include "ClsClient.h"
#include "ClsScreen.h"
#include "ClsInputValidate.h"
using namespace std;
class ClsTransferScreen : protected clsScreen
{
private:

    static void _PrintClient(clsBankClient Client)
    {
        cout << "\nClient Card:";
        cout << "\n___________________";
        cout << "\nFirstName   : " << Client.FirstName;
        cout << "\nAcc. Number : " << Client.AccountNumber();
        cout << "\nBalance     : " << Client.AccountBalance;
        cout << "\n___________________\n";

    }

    static string _ReadAccountNumber(string Msg)
    {
        string AccountNumber = "";
        cout << "\n " << Msg << endl;
        cin >> AccountNumber;
        return AccountNumber;
    }

public:

    static void ShowTransferScreen()
    {
        _DrawScreenHeader("\t   Transfer Screen");

        string AccountNumberFrom = _ReadAccountNumber("Please Enter Account number to Transfer From?");


        while (!clsBankClient::IsClientExist(AccountNumberFrom))
        {
            cout << "\nClient with [" << AccountNumberFrom << "] does not exist.\n";
            AccountNumberFrom = _ReadAccountNumber("Please Enter Account number to Transfer From?");
        }

        clsBankClient ClientFrom = clsBankClient::Find(AccountNumberFrom);
        _PrintClient(ClientFrom);



        string AccountNumberTO = _ReadAccountNumber("Please Enter Account number to Transfer To?");

        while (!clsBankClient::IsClientExist(AccountNumberTO))
        {
            cout << "\nClient with [" << AccountNumberTO << "] does not exist.\n";
            AccountNumberTO = _ReadAccountNumber("Please Enter Account number to Transfer To?");
        }

        clsBankClient ClientTo = clsBankClient::Find(AccountNumberTO);
        _PrintClient(ClientTo);

        double Amount = 0;
        cout << "\nPlease enter Transfer Amount ? ";
        Amount = clsInputValidate::ReadDblNumber();

        while (Amount > ClientFrom.AccountBalance)
        {
            cout << "\nAmount Exceeds the aviable Balance ,Enter Another Amount? ";
            Amount = clsInputValidate::ReadDblNumber();
        }

        cout << "\nAre you sure you want to perform this transaction? ";
        char Answer = 'n';
        cin >> Answer;

        if (Answer == 'Y' || Answer == 'y')
        {
            if (ClientFrom.Transfer(Amount, ClientTo))
            {
                cout << "\nTransfer Done Successfully.\n";
            }
            else
            {
                cout << "\nTransfer Failed.\n";
            }
        }
      
        _PrintClient(ClientFrom);
        _PrintClient(ClientTo);
    
    }


};
