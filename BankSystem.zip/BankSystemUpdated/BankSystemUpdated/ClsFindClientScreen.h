#pragma once
#include "ClsClient.h"
#include "ClsInputValidate.h"
#include "ClsScreen.h"
class ClsFindClientScreen :protected clsScreen
{
private :
		static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.AccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.AccountBalance;
		cout << "\n___________________\n";

	}
public :
	static void ShowFindClientScreen()
	{
		if (!CheckAccessRigths(clsUser::enPermissions::pFindClient))
		{
			return;
		}


		clsScreen::_DrawScreenHeader("\tFind Client Screen");
		
		cout << "\nPlease Enter client Account Number: ";
		string AccountNumber = clsInputValidate::ReadString();
		while (!clsBankClient::IsClientExist(AccountNumber))
		{
			cout << "\nAccount number is not found, choose another one: ";
			AccountNumber = clsInputValidate::ReadString();
		}
		clsBankClient Client1 = clsBankClient::Find(AccountNumber);
		if (Client1.IsEmpty())
		{
			cout << "\nThe Client was not found :-(\n";
		}
		else
			cout << "\nThe Client was found :-)";


		_PrintClient(Client1);




	}
};


