#pragma once
#include "ClsScreen.h"
#include <iostream>
#include "ClsCurrency.h"
#include "ClsInputValidate.h"
using namespace std;
class ClsFindCurrencyScreen : protected clsScreen
{
private :

	static void _PrintCurrency(ClsCurrency Currency)
	{
		cout << "\nCurrency Card:";
		cout << "\n___________________";
		cout << "\nCurrency Country : " << Currency.Country();
		cout << "\nCurrency Code    : " << Currency.CurrencyCode();
		cout << "\nCurrency Name    : " << Currency.CurrencyName();
		cout << "\nCurrency Rate(1$): " << Currency.Rate();
		cout << "\n___________________\n";
	}

	enum enFindOptions
	{
		eByCode = 1 , eByName = 2
	};

	static ClsCurrency _FindCurrencyByCode()
	{
		cout << "Enter Currency Code :";
		string CurrencyCode = clsInputValidate::ReadString();
		ClsCurrency Currency =  ClsCurrency::FindByCode(CurrencyCode);
		return (Currency);
	}

	static ClsCurrency _FindCurrencyByCountryName()
	{
		cout << "Enter Country Name :";
		string Country = clsInputValidate::ReadString();
		ClsCurrency Currency = ClsCurrency::FindByCountry(Country);
		return (Currency);
	}

	static ClsCurrency _Find(enFindOptions Option)
	{
		switch (Option)
		{
		case ClsFindCurrencyScreen::eByCode:
		{
			return _FindCurrencyByCode();
		}
		case ClsFindCurrencyScreen::eByName:
		{
			return _FindCurrencyByCountryName();
		}
      	}

	}

public:

	static void ShowFindCurrecnyScreen()
	{
		clsScreen::_DrawScreenHeader("\tFind CUrrecny Screen");

		cout << "\nFind By: [1] Code or [2] Country ? ";
		short Option = clsInputValidate::ReadShortNumber("Invalid Number , Please Enter 1 or 2");
		
		ClsCurrency Currecny = _Find((enFindOptions)Option);
		if (Currecny.IsEmpty())
		{
			cout << "\nThe Currency was not found :-(\n";
		}
		else
		{
			cout << "\nThe Client was found :-)";
			_PrintCurrency(Currecny);
		}


	



	}




};