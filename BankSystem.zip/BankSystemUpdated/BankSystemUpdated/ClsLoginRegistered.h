#pragma once
#include <iostream>
#include "ClsClient.h"
#include <iomanip>
#include "ClsScreen.h"
#include "clsUser.h"
using namespace std;
class ClsLoginRegistered :protected clsScreen
{
private:
    static void _PrintLoginRegisterRecordLine(clsUser::stLoginRegisterRecord LoginRegisterRecord)
    {
        cout << setw(8) << left << "" << "| " << setw(35) << left << LoginRegisterRecord.DateTime;
        cout << "| " << setw(20) << left << LoginRegisterRecord.UserName;
        cout << "| " << setw(20) << left << LoginRegisterRecord.Password;
        cout << "| " << setw(10) << left << LoginRegisterRecord.Permissions;
    }
public:
    static void ShowLoginRegistationList()
    {

        vector <clsUser::stLoginRegisterRecord> vLogin = clsUser::GetLoginRegisterList();
        string Title = "\t  Login Register List Screen";
        string SubTitle = "\t    (" + to_string(vLogin.size()) + ") Client(s).";

       _DrawScreenHeader(Title, SubTitle);
       if (!CheckAccessRigths(clsUser::enPermissions::pLoginRegister))
       {
           return;
       }
       cout << setw(8) << left << "" << "\n\t_______________________________________________________";
       cout << "_________________________________________\n" << endl;

       cout << setw(8) << left << "" << "| " << left << setw(35) << "Date/Time";
       cout << "| " << left << setw(20) << "UserName";
       cout << "| " << left << setw(20) << "Password";
       cout << "| " << left << setw(10) << "Permissions";
       cout << setw(8) << left << "" << "\n\t_______________________________________________________";
       cout << "_________________________________________\n" << endl;


        if (vLogin.size() == 0)
            cout << "\t\t\t\tNo Register Login Available In the System!";
        else
            for (clsUser::stLoginRegisterRecord C : vLogin)
            {
                _PrintLoginRegisterRecordLine(C);
                cout << endl;
            }
        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;
    }


};



