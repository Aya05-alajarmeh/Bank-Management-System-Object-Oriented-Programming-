#pragma once
#include <iostream>
#include "ClsScreen.h"
#include <string>
#include "ClsClient.h"
using namespace std;
class ClsTransferLogScreen: protected clsScreen
{
private:
    static void _PrintTransferRecordLine(clsBankClient::stTransferRigisterRecord TransferLogRecord)
    {
        cout << setw(8) << left << "" << "| " << setw(20) << left << TransferLogRecord.DateTime;
        cout << "| " << setw(5) << left << TransferLogRecord.AccountNumberFrom;
        cout << "| " << setw(5) << left << TransferLogRecord.AccountNumberTo;
        cout << "| " << setw(10) << left << TransferLogRecord.Amount;
        cout << "| " << setw(10) << left << TransferLogRecord.AccountBalanceFromAfter;
        cout << "| " << setw(10) << left << TransferLogRecord.AccoutBalanceTO;
        cout << "| " << setw(10) << left << TransferLogRecord.UserName;
    }

public:
	static void ClsShowTransferScreen()
	{
		vector<clsBankClient::stTransferRigisterRecord> vTransferLogRecords = clsBankClient::GetTransferLogList();
		string Title = "\t  Transfer Log List Screen";
		string SubTitle = "\t    (" + to_string(vTransferLogRecords.size()) + ") Client(s).";

		_DrawScreenHeader(Title, SubTitle);

        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;

        cout << setw(8) << left << "" << "| " << left << setw(20) << "Date/Time";
        cout << "| " << left << setw(10) << "s.Acct";
        cout << "| " << left << setw(10) << "d.Acct";
        cout << "| " << left << setw(10) << "Amount";
        cout << "| " << left << setw(10) << "s.Balance";
        cout << "| " << left << setw(10) << "d.Balance";
        cout << "| " << left << setw(10) << "User";
        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;


        if (vTransferLogRecords.size() == 0)
            cout << "\t\t\t\tNo Register Login Available In the System!";
        else
            for (clsBankClient::stTransferRigisterRecord C : vTransferLogRecords)
            {
                _PrintTransferRecordLine(C);
                cout << endl;
            }
        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;
    }



};