#pragma once
#include "clsUser.h"
#include<iostream>
clsUser CurrentUser = clsUser::Find("", "");


