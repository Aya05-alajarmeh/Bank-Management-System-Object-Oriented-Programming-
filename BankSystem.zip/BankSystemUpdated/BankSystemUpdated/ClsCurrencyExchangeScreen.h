#pragma once
#include "ClsScreen.h"
#include "ClsCurrency.h"
#include "ClsMainClientScreen.h"
#include"ClsListCurrencyScreen.h"
#include "ClsFindCurrencyScreen.h"
#include "ClsUpdateCurrencyRateScreen.h"
#include "ClsCurrencyCalculationSscreen.h"
#include <iostream>
#include <iomanip>
using namespace std;
class ClsCurrencyExchangescreen : protected clsScreen
{
private:
    enum enCurrencyMenueOptions
    {
        eListCurreny = 1, eFindCurrency = 2, eUpdateRate = 3, eCurrencyCalculator = 4, eMainMenue = 5
    };

    static  void _GoBackToCurrencyMenue()
    {
        cout << setw(37) << left << "" << "\n\tPress any key to go back to Currency Menue...\n";
        system("pause>0");
        showCurrencyExhangeScreen();
    }

    static short _ReadCurrencyMenueOption()
    {
        cout << setw(37) << left << "" << "Choose what do you want to do? [1 to 5]? ";
        short Choice = clsInputValidate::ReadShortNumberBetween(1, 5, "Enter Number between 1 to 5? ");
        return Choice;
    }

    static void _ShowAllCurrencyScreen()
    {
        clsListCurrencyScreen::ShowCurrenciesListScreen();
    }

    static void _ShowFindCurrencyScreen()
    {
        ClsFindCurrencyScreen::ShowFindCurrecnyScreen();
    }

    static void _ShowUpdateRateScreen()
    {
        clsUpdateCurrencyRateScreen::ShowUpdateCurrencyRateScreen();
    }

    static void _ShowCurrencyCalculateorScreen()
    {
        clsCurrencyCalculatorScreen::ShowCurrencyCalculatorScreen();
    }

    static void _PerfromCurrencyMenueOption(enCurrencyMenueOptions Option)
    {
        switch (Option) {
        case enCurrencyMenueOptions::eCurrencyCalculator:
        {
            system("cls");
            _ShowCurrencyCalculateorScreen();
            _GoBackToCurrencyMenue();
            break;
        }
        case enCurrencyMenueOptions::eFindCurrency: {
            system("cls");
            _ShowFindCurrencyScreen();
            _GoBackToCurrencyMenue();
            break;
        }

        case enCurrencyMenueOptions::eListCurreny: {
            system("cls");
            _ShowAllCurrencyScreen();
            _GoBackToCurrencyMenue();
            break;
        }

        case enCurrencyMenueOptions::eUpdateRate: {
            system("cls");
            _ShowUpdateRateScreen();
            _GoBackToCurrencyMenue();
            break;
        }

        case enCurrencyMenueOptions::eMainMenue:
        {

        }
        }
    }

public:
    static void showCurrencyExhangeScreen()
    {
        system("cls");
        _DrawScreenHeader("Currency Exchange Main Screen");

        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\tCurrency Exchange Menue\n";
        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t[1] List Currencies.\n";
        cout << setw(37) << left << "" << "\t[2] Find Currency.\n";
        cout << setw(37) << left << "" << "\t[3] Update Rate.\n";
        cout << setw(37) << left << "" << "\t[4] Currency Calculator.\n";
        cout << setw(37) << left << "" << "\t[5] Main Menue.\n";
        cout << setw(37) << left << "" << "===========================================\n";
        _PerfromCurrencyMenueOption((enCurrencyMenueOptions)_ReadCurrencyMenueOption());
    }
};
